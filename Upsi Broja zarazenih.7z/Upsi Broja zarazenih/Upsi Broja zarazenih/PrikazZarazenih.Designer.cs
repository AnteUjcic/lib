﻿namespace Upsi_Broja_zarazenih
{
    partial class PrikazZarazenih
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.graf = new LiveCharts.WinForms.CartesianChart();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Zarazeni = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.monthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.revBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnPrikazZarazenihLoad = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.revBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // graf
            // 
            this.graf.Location = new System.Drawing.Point(27, 12);
            this.graf.Name = "graf";
            this.graf.Size = new System.Drawing.Size(491, 266);
            this.graf.TabIndex = 3;
            this.graf.Text = "chart";
            this.graf.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.graf_ChildChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.yearDataGridViewTextBoxColumn,
            this.Zarazeni,
            this.monthDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.revBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(27, 301);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(361, 150);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            // 
            // Zarazeni
            // 
            this.Zarazeni.DataPropertyName = "Zarazeni";
            this.Zarazeni.HeaderText = "Zarazeni";
            this.Zarazeni.Name = "Zarazeni";
            // 
            // monthDataGridViewTextBoxColumn
            // 
            this.monthDataGridViewTextBoxColumn.DataPropertyName = "Month";
            this.monthDataGridViewTextBoxColumn.HeaderText = "Month";
            this.monthDataGridViewTextBoxColumn.Name = "monthDataGridViewTextBoxColumn";
            // 
            // revBindingSource
            // 
            this.revBindingSource.DataSource = typeof(Upsi_Broja_zarazenih.Rev);
            // 
            // btnPrikazZarazenihLoad
            // 
            this.btnPrikazZarazenihLoad.Location = new System.Drawing.Point(424, 301);
            this.btnPrikazZarazenihLoad.Name = "btnPrikazZarazenihLoad";
            this.btnPrikazZarazenihLoad.Size = new System.Drawing.Size(94, 150);
            this.btnPrikazZarazenihLoad.TabIndex = 5;
            this.btnPrikazZarazenihLoad.Text = "Ucitaj";
            this.btnPrikazZarazenihLoad.UseVisualStyleBackColor = true;
            this.btnPrikazZarazenihLoad.Click += new System.EventHandler(this.btnPrikazZarazenihLoad_Click);
            // 
            // PrikazZarazenih
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 450);
            this.Controls.Add(this.btnPrikazZarazenihLoad);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.graf);
            this.Name = "PrikazZarazenih";
            this.Text = "PrikazZarazenih";
            this.Load += new System.EventHandler(this.PrikazZarazenih_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.revBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private LiveCharts.WinForms.CartesianChart graf;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn valueDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource revBindingSource;
        private System.Windows.Forms.Button btnPrikazZarazenihLoad;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Zarazeni;
        private System.Windows.Forms.DataGridViewTextBoxColumn monthDataGridViewTextBoxColumn;
    }
}