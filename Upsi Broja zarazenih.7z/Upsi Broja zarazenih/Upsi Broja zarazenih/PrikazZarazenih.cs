﻿using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
namespace Upsi_Broja_zarazenih
{
    public partial class PrikazZarazenih : Form
    {
        public PrikazZarazenih()
        {
            InitializeComponent();
        }

        private void btnPrikazZarazenihLoad_Click(object sender, EventArgs e)
        {
            
            XmlSerializer serializer = new XmlSerializer(typeof(List<Zarazeni>));

            using (FileStream stream = File.OpenRead("Zarazeni"))
            {
                List<Zarazeni> xmlInput = (List<Zarazeni>)serializer.Deserialize(stream);
            }


            graf.Series.Clear();
            SeriesCollection series = new SeriesCollection();                                                                                                   
            var years=(from o in revBindingSource.DataSource as List<Zarazeni>
                       select new {Year= o.DatumUpisa}).Distinct();
            foreach(var year in years)
            {
                List<double> values=new List<double>();
                for(int month=1; month<=12; month++)
                {
                    double value = 0;
                    var data = from o in revBindingSource.DataSource as List<Rev>
                               where o.Year.Equals(year.Year) && o.Month.Equals(month)
                               orderby o.Month ascending
                               select new { o.Zarazeni, o.Month };
                    if (data.SingleOrDefault() != null)
                    {
                        value = data.SingleOrDefault().Zarazeni;
                        values.Add(value);
                    }
                }
                series.Add(new LineSeries() { Title = year.Year.ToString(), Values = new ChartValues<double>(values) });

            }
            graf.Series= series;
                            
        }

        private void PrikazZarazenih_Load(object sender, EventArgs e)
        {
            revBindingSource.DataSource = new List<Rev>();
            graf.AxisX.Add(new LiveCharts.Wpf.Axis
            {
                Title = "Month",
                Labels = new[] {"Jan","Feb","Mar","Apr","May","Jun",
                                "Jul","Aug","Sep","Oct","Nov","Dec"}
            });
            graf.AxisY.Add(new LiveCharts.Wpf.Axis
            { 
                Title="Zarazeni",
                LabelFormatter=value => value.ToString("C")

            });
            graf.LegendLocation = LiveCharts.LegendLocation.Right;
        }

        private void graf_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
